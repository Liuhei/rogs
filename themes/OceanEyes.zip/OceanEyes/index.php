<?php get_header(); ?>
        <div id="content">
           <div class="inner-content">
               <main id="main">
                <section>
                    <h1 id="h1-top">最新の投稿</h1>
                    <?php if (have_posts()):
                        while (have_posts()):the_post(); ?>
                            <div class="category-box-top">
                                <div class="category-box-img">
                                    <a href="<?php echo esc_url(get_the_permalink()); ?>">
                                        <?php if ( has_post_thumbnail() ) {
                                            echo get_the_post_thumbnail();
                                        } else { ?>
                                            <img src="<?php echo get_template_directory_uri(); ?>/images/DonutsShop.jpg" width="500">  
                                        <?php } ?>
                                    </a>
                                </div>
                                <div class="category-box-contents">
                                    <h2 class="category-title-top"><a href="<?php echo esc_url(get_the_permalink()); ?>"><?php the_title(); ?></a></h2>
                                    <div class="category-details-box">
                                        <p class="category-author-top"><?php echo get_the_author(); ?></p>
                                        <p class="category-date-top"><?php echo the_time('Y.n.j'); ?></p>
                                    </div>
                                </div>
                            </div>
                    <?php
                    endwhile;
                    endif; 
                    ?>
                </section>
               </main>
<?php get_sidebar(); ?>
<?php get_footer(); ?>
        