<!DOCTYPE html>
<html lang="ja">

<head>
    <meta charset="utf-8">
    <title>OceanEyes</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/style.css">
    <script src="https://kit.fontawesome.com/5d4284b50c.js" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <?php wp_head(); ?>
</head>
<body>
    <div id="container">
        <header>
           <div id="inner-header">
            <a href="<?php echo esc_url(home_url()); ?>" class="logo-anchor"><div id="header-contens">
                <p id="logo">
                    <?php echo get_bloginfo('name'); ?>
                </p>
                <p id="header-description">
                    <?php echo get_bloginfo('description') ?>
                </p>
            </div></a>
            <nav>
               <div class="nav-box">
                <?php
                   $args = array(
                   'container' => false,
                   );
                   wp_nav_menu($args);
                 ?>
               </div>
            </nav>
          </div>
        </header>