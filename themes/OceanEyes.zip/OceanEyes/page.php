<?php get_header(); ?>
        <div id="content">
           <div class="inner-content">
               <main id="main">
                <section id="post-page-section">
                    <h1 class="post-title"><?php echo the_title(); ?></h1>
                    <div class="post-page-info">
                        <p class="category-author-top post-author">
                            <?php if (have_posts()) {
                                while (have_posts()) {
                                    the_post();
                                    the_author();
                                }
                            }
                            ?>
                        </p>
                        <p class="category-date-top"><?php echo the_time('Y.n.j'); ?></p>
                    </div>
                    <p class="post-thumbnail">
                    <?php if ( has_post_thumbnail() ) {
                        echo get_the_post_thumbnail();
                    } else { ?>
                        <img src="<?php echo get_template_directory_uri(); ?>/images/DonutsShop.jpg" width="500">  
                    <?php } ?>
                    <?php if ( have_posts() ) : while ( have_posts() ) : the_post();
                        the_content();
                    endwhile; else: ?>
                        <p></p>
                    <?php endif; ?>
                    </p>
                </section>
               </main>
            <?php get_sidebar(); ?>
         </div>
        </div>
        <?php get_footer(); ?>